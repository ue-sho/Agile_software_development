#include "Affiliation.h"

Affiliation::~Affiliation()
{
}

Affiliation::Affiliation()
{
}
