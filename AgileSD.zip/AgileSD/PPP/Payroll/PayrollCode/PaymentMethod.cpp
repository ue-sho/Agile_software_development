#include "PaymentMethod.h"

PaymentMethod::~PaymentMethod()
{
}
