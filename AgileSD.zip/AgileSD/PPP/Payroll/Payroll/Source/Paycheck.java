
public class Paycheck
{
  private int itsGrossPay = 0;

  public Paycheck(int grossPay )
  {
    itsGrossPay = grossPay;
  }
  public int grossPay()
  {
    return itsGrossPay;
  }
}
