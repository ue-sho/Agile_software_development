import org.jdom.Document;

public interface PaycheckWriter
{
  public void write(Document doc);
}
