
public class Square implements Shape
{
  public String getShapeName()
  {
    return "Square";
  }
}
