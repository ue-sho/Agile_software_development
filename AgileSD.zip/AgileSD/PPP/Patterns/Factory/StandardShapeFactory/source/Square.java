
public class Square implements Shape
{
  public String getShapeType()
  {
    return "Square";
  }
}
